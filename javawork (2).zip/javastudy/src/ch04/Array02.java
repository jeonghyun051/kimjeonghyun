package ch04;

class Police{
	private String name="����";

}

class Doctor{
	private String name="�ǻ�";

	}

	public static void main(String[] args) {
		
	}

	}
