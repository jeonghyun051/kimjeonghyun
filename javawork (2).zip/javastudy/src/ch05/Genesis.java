package ch05;

public class Genesis extends Car implements Control{
	private String name;
	private Engine2000 engine2000;
	
	@Override
	public void ����() {
		// TODO Auto-generated method stub
		System.out.println("����");
	}
	@Override
	public void �극��ũ() {
		// TODO Auto-generated method stub
		System.out.println("����");
	}
	
	
}
