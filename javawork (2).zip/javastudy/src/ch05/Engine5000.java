package ch05;

public class Engine5000 {

}
