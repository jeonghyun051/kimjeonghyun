package ch05;

public class GameApp {

	static void start(Control c) {
		c.����();
		c.�극��ũ();
		
	}
	
	public static void main(String[] args) {
		Sonata s = new Sonata();
		start(s);
		
		Genesis g = new Genesis();
		start(g);

	}

}
