package ch03;

public class Input04 {

	public static void main(String[] args) {
		MyScanner sc = new MyScanner();
		String data = sc.getData();
		System.out.println(data);

	}

}
