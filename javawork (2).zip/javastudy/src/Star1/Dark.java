package Star1;

class Dark extends StarUnit{
	private String name;
	private int hp;
	private int attack;
	
	public Dark(String n, int h, int a) {
		
		name = n;
		hp = h;
		attack = a;
		
		

	}

}
