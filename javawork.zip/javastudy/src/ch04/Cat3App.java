package ch04;

public class Cat3App {

	public static void main(String[] args) {
		Cat3 c = new Cat3();
		c.setName("������1");
		c.setAge(1);
		c.setColor("�Ͼ��");
		

	}

}
