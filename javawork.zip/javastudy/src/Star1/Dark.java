package Star1;

class Dark {
	String name;
	int hp;
	int attack;
	
	public Dark(String n, int h, int a) {
		
		name = n;
		hp = h;
		attack = a;
		
		
		
	}

}
