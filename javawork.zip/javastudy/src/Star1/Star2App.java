package Star1;

public class Star2App {

	public static void main(String[] args) {
	
		Marine m = new Marine();
		
		Dragon d = new Dragon();
		d.name = "���1";
		d.hp = 100;
		d.attack = 20;
		

	}

}
