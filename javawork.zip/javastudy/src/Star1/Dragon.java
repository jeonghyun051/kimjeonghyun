package Star1;

class Dragon {
	 String name;
	 int hp;
	 int attack;
	
	public Dragon() {
		
	}
	
	public Dragon(String n, int h, int a) {
		
		name = n;
		hp = h;
		attack = a;
		
		
		
	}

}
